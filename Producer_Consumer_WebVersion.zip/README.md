# Producer-Consumer Problem Simulation

This project simulates the Producer-Consumer problem using Python threading and semaphores.