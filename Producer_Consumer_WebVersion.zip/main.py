# Main script for Producer-Consumer simulation
print('Run simulation')